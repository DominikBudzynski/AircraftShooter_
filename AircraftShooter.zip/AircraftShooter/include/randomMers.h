#pragma once
#include "Header.h"

/*
Return:
 Returns int random value from down_range to up_range
Parameters:
 int down_range - start of the range
 int up_range - end of the range
*/
int randomMers(int down_range, int up_range);